# -*- coding: utf-8 -*-

"""
01

Create and initialize following variables. Variable name and initial value is given in parenthesis:

- Approximate value of pi:      (approx_pi, 3.14)
- Street address:               (street_address, Kauppakatu 12)
- Social security number:       (social_security_number, 211278-234X)
- First letter of a name:       (name_first, j)
- Current temperature outside:  (temperature, 12.5)

Print content of each variable, one variable for each line
"""

approx_pi = 3.14;
street_address = "Kauppakatu 12";
social_security_number = "211278-234X";
name_first = "j";
temperature = 12.5;

print(approx_pi);
print(street_address);
print(social_security_number);
print(name_first);
print(temperature);